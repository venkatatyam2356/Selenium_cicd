from selenium.webdriver.common.by import By
import time

class ExpensePage:
    def __init__(self, driver):
        self.driver = driver

    def add_expense(self, title, amount, category, date):
        time.sleep(10)
        self.driver.find_element(By.LINK_TEXT, "+Add Expense").click()
        self.driver.find_element(By.ID, "title").send_keys(title)
        self.driver.find_element(By.ID, "amount").send_keys(amount)
        self.driver.find_element(By.ID, "category").send_keys(category)
        self.driver.find_element(By.ID, "date").send_keys(date)
        self.driver.find_element(By.XPATH, "//button[@type='submit']").click()
        time.sleep(1)

    def edit_first_expense(self, new_amount):
        self.driver.find_element(By.XPATH, "//i[@class='fas fa-edit']").click()
        amount = self.driver.find_element(By.NAME, "amount")
        amount.clear()
        amount.send_keys(new_amount)
        self.driver.find_element(By.XPATH, "//button[@type='submit']").click()
        time.sleep(1)

    def delete_first_expense(self):
        self.driver.find_element(By.XPATH, "//i[@class='fas fa-trash-alt']").click()
        self.driver.find_element(By.XPATH, "//button[@type='submit']").click()
        time.sleep(1)
