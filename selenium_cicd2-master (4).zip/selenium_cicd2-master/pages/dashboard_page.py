from selenium.webdriver.common.by import By

class DashboardPage:
    def __init__(self, driver):
        self.driver = driver

    def change_currency(self, currency):
        dropdown = self.driver.find_element(By.ID, "currencySelect")
        dropdown.send_keys(currency)

    def go_to_dashboard(self):
        self.driver.find_element(By.LINK_TEXT, "Dashboard").click()

    def go_to_reports(self):
        self.driver.find_element(By.LINK_TEXT, "Reports").click()

    def logout(self):
        self.driver.find_element(By.LINK_TEXT, "Logout").click()
