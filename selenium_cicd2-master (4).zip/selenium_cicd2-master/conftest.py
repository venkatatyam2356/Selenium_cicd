import pytest
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service

@pytest.fixture(scope="class")
def init_driver(request):
    options = Options()
    options.add_argument("--headless=new")  # preferred modern headless mode
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--no-sandbox")
    options.add_argument("--window-size=1920,1080")

    service = Service()  # if needed, pass path to chromedriver

    driver = webdriver.Chrome(service=service, options=options)
    driver.implicitly_wait(10)
    request.cls.driver = driver

    yield
    driver.quit()
