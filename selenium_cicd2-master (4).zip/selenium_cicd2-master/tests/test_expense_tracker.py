import pytest
from selenium.webdriver.common.by import By
from pages.login_page import LoginPage
from pages.expense_page import ExpensePage
from pages.dashboard_page import DashboardPage
from utils.logger import get_logger

logger = get_logger()

@pytest.mark.usefixtures("init_driver")
class TestExpenseTracker:
    def test_login(self):
        self.driver.get("http://localhost:8000/")
        LoginPage(self.driver).login("venkat23", "Venkat@2356")

    # def test_logout(self):
    #     DashboardPage(self.driver).logout()

    def test_add_expense(self):
        ExpensePage(self.driver).add_expense("clothes", "350", "Shopping", "15-05-2024")
        assert "clothes" in self.driver.page_source
        logger.info("Expense added.")

    def test_edit_expense(self):
        ExpensePage(self.driver).edit_first_expense("450")
        assert "450" in self.driver.page_source
        logger.info("Expense edited.")

    def test_delete_expense(self):
        ExpensePage(self.driver).delete_first_expense()
        logger.info("Expense deleted.")

    def test_currency_change(self):
        DashboardPage(self.driver).change_currency("Europe EUR")
        logger.info("Currency changed.")

    def test_navigate_dashboard(self):
        DashboardPage(self.driver).go_to_dashboard()
        assert "Total Expense" in self.driver.page_source
        logger.info("Navigated to Dashboard.")

    def test_navigate_reports(self):
        DashboardPage(self.driver).go_to_reports()
        assert "Monthly" in self.driver.page_source or "category" in self.driver.page_source.lower()
        logger.info("Navigated to Reports.")

    def test_logout(self):
        DashboardPage(self.driver).logout()
        logger.info("Logout successful.")
