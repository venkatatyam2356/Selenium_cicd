# logger.py
import logging


def get_logger(name="ExpenseTrackerLogger"):
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)

    if not logger.handlers:  #Prevent duplicate handlers
        handler = logging.FileHandler("tests/test_log.log", mode='w')  #Store under tests/ for clarity
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)

    return logger
