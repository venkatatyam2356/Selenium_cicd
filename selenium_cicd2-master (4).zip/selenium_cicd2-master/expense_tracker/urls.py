from django.contrib import admin
from django.urls import path, include
from django.contrib.auth import views as auth_views
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView  # For JWT Authentication

urlpatterns = [
    # ⚙️ Admin Panel
    path('admin/', admin.site.urls),

    # 🏠 Main Application Routes
    path('', include('expenses.urls')),

    # 🔐 Authentication Routes
    path('accounts/', include('django.contrib.auth.urls')),  # Django built-in auth views
    path('login/', auth_views.LoginView.as_view(template_name='expenses/login.html'), name='login'),

    # 🌍 API Endpoints
    path('api/', include('expenses.api_urls')),  # All API routes

    # 🔑 JWT Authentication Endpoints
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
]
