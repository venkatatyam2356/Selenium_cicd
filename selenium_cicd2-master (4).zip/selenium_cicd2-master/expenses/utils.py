import requests
from django.core.cache import cache

EXCHANGE_API_KEY = "20c3615ed1e48fc8dd575cd6"  # Replace with your API key
BASE_CURRENCY = "USD"  # Default currency
CACHE_TIMEOUT = 3600  # 1 hour

def get_exchange_rates():
    """Fetch exchange rates and cache them for 1 hour."""
    cache_key = "exchange_rates"
    rates = cache.get(cache_key)

    if not rates:
        url = f"https://v6.exchangerate-api.com/v6/{EXCHANGE_API_KEY}/latest/{BASE_CURRENCY}"
        try:
            response = requests.get(url, timeout=10)  # Set timeout to avoid hanging
            response.raise_for_status()  # Raise error for bad responses (4xx, 5xx)
            data = response.json()
            
            if data.get("result") == "success":
                rates = data.get("conversion_rates", {})
                cache.set(cache_key, rates, timeout=CACHE_TIMEOUT)
            else:
                print(f"Exchange rate API error: {data.get('error-type', 'Unknown error')}")
                rates = {}
        except requests.exceptions.RequestException as e:
            print(f"Error fetching exchange rates: {e}")
            rates = {}

    return rates

def convert_currency(amount, target_currency):
    """Convert amount from base currency (USD) to target currency."""
    rates = get_exchange_rates()
    conversion_rate = rates.get(target_currency, 1)  # Default to 1 if not found
    return round(amount * conversion_rate, 2)
