# expenses/forms.py
from django import forms
from .models import Expense 

class ExpenseForm(forms.ModelForm):
    class Meta:
        model = Expense
        fields = ['title', 'amount', 'category', 'date', 'description']
        widgets = {
            'date': forms.DateInput(attrs={'type': 'date'}),
        }

# class CategoryForm(forms.ModelForm):
#     class Meta:
#         model = Category
#         fields = ['name']
