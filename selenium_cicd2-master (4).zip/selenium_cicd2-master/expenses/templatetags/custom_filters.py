from django import template
from django.template.defaultfilters import stringfilter

register = template.Library()

@register.filter(name='add_class')
def add_class(value, arg):
    return value.as_widget(attrs={'class': arg})

@register.filter(name='get_item')
def get_item(dictionary, key):
    try:
        return dictionary[key]
    except KeyError:
        return None
    
@register.filter(name='sum_values')
def sum_values(dictionary):
    return sum(dictionary.values()) if dictionary else 0

@register.filter
@stringfilter
def replace(value, arg):
    """Replaces all instances of old with new"""
    old, new = arg.split(',')
    return value.replace(old, new)

@register.filter
def replace(value, args):
    """Usage: {{ value|replace:"old/new" }}"""
    old, new = args.split('/')
    return value.replace(old, new)