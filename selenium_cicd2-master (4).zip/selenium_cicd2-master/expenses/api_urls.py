from django.urls import path
from . import views

urlpatterns = [
    path('expenses/', views.expenses_list, name='api_expenses'),
    # path('expenses/<int:id>/', views.expense_detail, name='api_expense_detail'),
]
