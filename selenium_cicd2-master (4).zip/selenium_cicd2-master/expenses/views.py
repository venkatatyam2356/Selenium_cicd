# expenses/views.py
from venv import logger
from django.http import JsonResponse
from django.shortcuts import render, redirect
from django.db.models.functions import TruncMonth, TruncYear
from django.contrib.auth import logout
import requests
from .models import Expense, Category
from .serializers import ExpenseSerializer
from rest_framework import generics, permissions
from .forms import ExpenseForm
from django.contrib.auth.decorators import login_required
from django.db.models import Sum
from django.contrib.auth.models import User
from django.contrib.auth import login
from django.contrib import messages
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.core.paginator import Paginator
from datetime import datetime
from collections import defaultdict
from decimal import Decimal
import random
from rest_framework.views import APIView
from rest_framework import status
import calendar
from django.db.models import F,Sum, Func
from expenses import models
from django.shortcuts import HttpResponse
import csv,json
from fpdf import FPDF
from .utils import convert_currency, get_exchange_rates
from reportlab.pdfgen import canvas
from rest_framework.decorators import api_view
from rest_framework.response import Response
from .serializers import ExpenseSerializer
from django import forms
from django.shortcuts import get_object_or_404
# from .models import Expense  # Remove 'Category'

# PASSWORD_STRENGTH_API = "https://jbcss4xjuua4s4ihxn5hv5glo40ejyau.lambda-url.eu-west-1.on.aws/"
API_BASE_URL = "https://f2vvs1iwud.execute-api.eu-west-1.amazonaws.com/prod/api"
EXPENSES_API_ENDPOINT = f"{API_BASE_URL}/expenses"
SAVINGS_API_URL = "https://s5n43ij2al.execute-api.eu-west-1.amazonaws.com/prod/plan-savings"

@login_required
def dashboard(request):
    expenses = Expense.objects.filter(user=request.user).order_by('date')

    expenses_by_category = defaultdict(lambda: {"year_data": {}, "total": Decimal(0)})
    total_expense = Decimal(0)

    for expense in expenses:
        try:
            amount = expense.amount or Decimal(0)
            category = expense.category or "Other"
            date = expense.date
            year = date.year

            total_expense += amount
            expenses_by_category[category]["total"] += amount
            expenses_by_category[category]["year_data"].setdefault(year, {"amount": Decimal(0)})
            expenses_by_category[category]["year_data"][year]["amount"] += amount
        except Exception as e:
            print(f"⚠️ Error processing expense {expense.id}: {e}")

    # Add percentages and max flag
    for category, data in expenses_by_category.items():
        max_amount = max((v["amount"] for v in data["year_data"].values()), default=Decimal(0))
        for year, year_data in data["year_data"].items():
            year_data["percentage"] = (year_data["amount"] / total_expense * 100) if total_expense else 0
            year_data["is_max"] = year_data["amount"] == max_amount

    year_colors = {
        year: f'#{random.randint(0, 0xFFFFFF):06x}'
        for category_data in expenses_by_category.values()
        for year in category_data["year_data"].keys()
    }

    return render(request, "expenses/dashboard.html", {
        "total_expense": total_expense,
        "expenses_by_category": dict(expenses_by_category),
        "year_colors": year_colors
    })


# @login_required
# def dashboard(request):
#     expenses = Expense.objects.filter(user=request.user)
#     total_expense = expenses.aggregate(Sum('amount'))['amount__sum'] or 0
#     categories = Category.objects.filter(user=request.user)
#     category_expenses = expenses.values('category__name').annotate(total=Sum('amount'))
#     context = {
#         'total_expense': total_expense,
#         'category_expenses': category_expenses,
#         'categories': categories,
#     }
#     return render(request, 'expenses/dashboard.html', context)

@login_required
def add_expense(request):
    if request.method == "POST":
        form = ExpenseForm(request.POST)
        if form.is_valid():
            expense = form.save(commit=False)
            expense.user = request.user
            expense.save()
            messages.success(request, "Expense added successfully!")
            return redirect('expenses:expenses_list')
    else:
        form = ExpenseForm()
    return render(request, 'expenses/add_expense.html', {"form": form})

class SimpleExpenseForm(forms.Form):
    title = forms.CharField(max_length=255)
    amount = forms.DecimalField(max_digits=10, decimal_places=2)
    category = forms.CharField(max_length=100)
    date = forms.DateField(widget=forms.DateInput(attrs={"type": "date"}))

@login_required
def edit_expense(request, pk):
    expense = get_object_or_404(Expense, pk=pk, user=request.user)

    if request.method == "POST":
        form = ExpenseForm(request.POST, instance=expense)
        if form.is_valid():
            form.save()
            messages.success(request, "Expense updated successfully!")
            return redirect("expenses:expenses_list")
    else:
        form = ExpenseForm(instance=expense)  # ✅ Prefill form with existing data

    return render(request, "expenses/edit_expense.html", {"form": form})



# @login_required
# def edit_expense(request, pk):
#     is_local = False
#     expense = None

#     try:
#         # Try to fetch from API
#         response = requests.get(f"{EXPENSES_API_ENDPOINT}/{pk}")
#         response.raise_for_status()
#         api_data = response.json()
#         expense_data = json.loads(api_data.get("body", "{}"))
#         is_local = False
#     except Exception as e:
#         messages.error(request, f"Error fetching expense: {e}")
#         return redirect("expenses:expenses_list")

#     if request.method == "POST":
#         form = SimpleExpenseForm(request.POST)
#         if form.is_valid():
#             updated_expense_data = form.cleaned_data
#             headers = {"Content-Type": "application/json"}
#             try:
#                 put_response = requests.put(
#                     f"{EXPENSES_API_ENDPOINT}/{pk}",
#                     json=updated_expense_data,
#                     headers=headers,
#                 )
#                 put_response.raise_for_status()
#                 messages.success(request, "Expense updated successfully!")
#                 return redirect("expenses:expenses_list")
#             except Exception as e:
#                 messages.error(request, f"Update failed: {e}")
#     else:
#         form = SimpleExpenseForm(initial=expense_data)

#     return render(request, "expenses/edit_expense.html", {"form": form})



@login_required
def delete_expense(request, pk):
    expense = get_object_or_404(Expense, pk=pk, user=request.user)

    if request.method == "POST":
        expense.delete()
        messages.success(request, "Expense deleted.")
        return redirect("expenses:expenses_list")  # ✅ Use namespaced redirect

    return render(request, "expenses/delete_expense.html", {"expense": expense})

def expense_category_data(request):
    # Fetch the data for categories
    categories = Expense.objects.values('category')  # Replace with your actual model field
    category_data = {}

    for category in categories:
        category_data[category['category']] = category_data.get(category['category'], 0) + 1  # Example: count expenses by category

    # Prepare the labels and data to be returned as JSON
    labels = list(category_data.keys())
    data = list(category_data.values())

    return JsonResponse({'labels': labels, 'data': data})

def home(request):
    return render(request, 'expenses/home.html')

def register(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        confirm_password = request.POST['confirm_password']

        if password != confirm_password:
            messages.error(request, "Passwords do not match.")
            return render(request, 'expenses/register.html')

        # # ✅ Password strength check via API
        # try:
        #     response = requests.post(
        #         PASSWORD_STRENGTH_API,
        #         json={"password": password},
        #         headers={"Content-Type": "application/json"}
        #     )
        #     response.raise_for_status()
        #     result = response.json()

        #     if result.get("strength") != "strong":
        #         suggestions = result.get("suggestions", [])
        #         msg = "Password is too weak."
        #         if suggestions:
        #             msg += " Suggestions: " + ", ".join(suggestions)
        #         messages.error(request, msg)
        #         return render(request, 'expenses/register.html')

        # except Exception as e:
        #     messages.error(request, f"Error checking password strength: {e}")
        #     return render(request, 'expenses/register.html')

        # ✅ Proceed with registration if password is strong
        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already taken.")
        elif User.objects.filter(email=email).exists():
            messages.error(request, "Email is already registered.")
        else:
            user = User.objects.create_user(username=username, email=email, password=password)
            user.save()
            login(request, user)
            messages.success(request, "Registration successful!")
            return redirect('expenses:dashboard')

    return render(request, 'expenses/register.html')

@login_required
def logout_view(request):
    logout(request)
    return redirect('home')

@login_required
def reports_view(request):
    try:
        expenses = Expense.objects.filter(user=request.user).order_by('date')

        category_expenses = defaultdict(Decimal)
        monthly_expenses = defaultdict(Decimal)

        for expense in expenses:
            try:
                category = expense.category or 'Other'
                amount = expense.amount or Decimal(0)
                date = expense.date

                category_expenses[category] += amount
                month_key = date.replace(day=1)  # First day of the month
                monthly_expenses[month_key] += amount
            except Exception as e:
                logger.warning(f"Skipping invalid expense: {expense} | Error: {e}")

        context = {
            'category_expenses': [{'category': k, 'total': v} for k, v in category_expenses.items()],
            'monthly_expenses': [{'month': k, 'total': v} for k, v in sorted(monthly_expenses.items())],
        }
        return render(request, 'expenses/reports.html', context)

    except Exception as e:
        logger.error(f"Error generating reports: {e}")
        return render(request, 'expenses/reports.html', {'category_expenses': [], 'monthly_expenses': []})

@login_required
def settings_view(request):
    if request.method == "POST":
        # Handle user profile updates
        username = request.POST.get("username")
        email = request.POST.get("email")

        if username and email:
            request.user.username = username
            request.user.email = email
            request.user.save()
            messages.success(request, "Settings updated successfully!")
            return redirect("settings")  # Redirect to the settings page

        else:
            messages.error(request, "Please fill in all fields.")

    return render(request, "expenses/settings.html")

@login_required
def expenses_list(request):
    try:
        expenses = Expense.objects.filter(user=request.user).order_by('-date')
        return render(request, 'expenses/expenses_list.html', {'expenses': expenses})


    except Exception as e:
        print(f"❌ Exception: {e}")
        messages.error(request, f"Error fetching expenses: {e}")
        return render(request, 'expenses/expenses_list.html', {'expense': []})


# @login_required
# def edit_expense(request, pk):
#     expense = Expense.objects.get(pk=pk, user=request.user)
#     if request.method == 'POST':
#         expense.title = request.POST['title']
#         expense.amount = request.POST['amount']
#         expense.category = request.POST['category']
#         expense.date = request.POST['date']
#         expense.save()
#         return redirect('expenses_list')  # Redirect to the list of expenses
#     return render(request, 'expenses/edit_expense.html', {'expense': expense})

# @login_required
# def delete_expense(request, pk):
#     expense = Expense.objects.get(pk=pk, user=request.user)
#     if request.method == 'POST':
#         expense.delete()
#         return redirect('expenses_list')  # Redirect to the list of expenses
#     return render(request, 'expenses/delete_expense.html', {'expense': expense})


# def download_expenses(request, format):
#     expenses = Expense.objects.all()

#     if format == 'csv':
#         response = HttpResponse(content_type='text/csv')
#         response['Content-Disposition'] = 'attachment; filename="expenses.csv"'
#         writer = csv.writer(response)
#         writer.writerow(['Title', 'Category', 'Amount', 'Date'])
#         for expense in expenses:
#             writer.writerow([expense.title, expense.category, expense.amount, expense.date])
#         return response

#     elif format == 'pdf':
#         response = HttpResponse(content_type='application/pdf')
#         response['Content-Disposition'] = 'attachment; filename="expenses.pdf"'
#         p = canvas.Canvas(response)
#         p.drawString(100, 800, "Expenses List")
#         y = 780
#         for expense in expenses:
#             y -= 20
#             p.drawString(100, y, f"{expense.title} - {expense.category} - ${expense.amount} - {expense.date}")
#         p.showPage()
#         p.save()
#         return response

#     return HttpResponse("Invalid format", status=400)

def convert_currency_view(request):
    amount = float(request.GET.get("amount", 0))
    currency = request.GET.get("currency", "USD")

    converted_amount = convert_currency(amount, currency)
    
    return JsonResponse({
        "converted_amount": converted_amount,
        "currency_symbol": get_currency_symbol(currency)
    })

def get_currency_symbol(currency_code):
    """Returns the appropriate currency symbol."""
    symbols = {
        "USD": "$", "EUR": "€", "GBP": "£", "INR": "₹", "JPY": "¥"
    }
    return symbols.get(currency_code, currency_code)  # Default to currency code

# @api_view(['GET', 'POST'])
# def expenses_list(request):
#     if request.method == 'GET':
#         expenses = Expense.objects.all()
#         serializer = ExpenseSerializer(expenses, many=True)
#         return Response(serializer.data)

#     if request.method == 'POST':
#         serializer = ExpenseSerializer(data=request.data)
#         if serializer.is_valid():
#             serializer.save()
#             return Response(serializer.data, status=201)
#         return Response(serializer.errors, status=400)



@login_required
def download_expenses(request, format):
    api_url = EXPENSES_API_ENDPOINT
    expenses_data = []

    try:
        response = requests.get(api_url)
        response.raise_for_status()
        data = response.json()
        expenses_data = json.loads(data.get('body', '[]'))
        logger.info(f"Fetched expenses for download ({format}): {expenses_data}")
    except requests.exceptions.RequestException as e:
        messages.error(request, f"Error fetching expenses for download from API: {e}")
        return HttpResponse("Error fetching data for download", status=500)
    except json.JSONDecodeError as e:
        messages.error(request, f"Error decoding API response for download: {e}")
        return HttpResponse("Error decoding data for download", status=500)
    except Exception as e:
        messages.error(request, f"An unexpected error occurred during download: {e}")
        return HttpResponse("An error occurred during download", status=500)

    if format == 'csv':
        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="expenses.csv"'
        writer = csv.writer(response)
        writer.writerow(['Title', 'Category', 'Amount', 'Date'])
        for expense in expenses_data:
            writer.writerow([
                expense.get('title', ''),
                expense.get('category', ''),
                expense.get('amount', ''),
                expense.get('date', '')
            ])
        return response

    elif format == 'pdf':
        response = HttpResponse(content_type='application/pdf')
        response['Content-Disposition'] = 'attachment; filename="expenses.pdf"'
        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Arial", size=12)
        pdf.cell(200, 10, txt="Expense Report", ln=True, align='C')
        for expense in expenses_data:
            pdf.cell(200, 10, txt=f"{expense.get('title', '')} - {expense.get('category', '')} - ${expense.get('amount', '')} - {expense.get('date', '')}", ln=True)
        response.write(pdf.output(dest='S').encode('latin1'))
        return response

    return HttpResponse("Invalid format", status=400)
# def export_expenses(request):
#     format = request.GET.get('format', 'csv')

#     expenses = Expense.objects.all()

#     if format == 'csv':
#         response = HttpResponse(content_type='text/csv')
#         response['Content-Disposition'] = 'attachment; filename="expenses.csv"'

#         writer = csv.writer(response)
#         writer.writerow(['Title', 'Category', 'Amount', 'Date'])

#         for expense in expenses:
#             writer.writerow([expense.title, expense.category, expense.amount, expense.date])

#         return response

#     elif format == 'pdf':
#         response = HttpResponse(content_type='application/pdf')
#         response['Content-Disposition'] = 'attachment; filename="expenses.pdf"'

#         pdf = FPDF()
#         pdf.add_page()
#         pdf.set_font("Arial", size=12)
#         pdf.cell(200, 10, txt="Expense Report", ln=True, align='C')

#         for expense in expenses:
#             pdf.cell(200, 10, txt=f"{expense.title} - {expense.category} - ${expense.amount} - {expense.date}", ln=True)

#         response.write(pdf.output(dest='S').encode('latin1'))
#         return response

class ExpenseListCreateAPIView(APIView):
    def get(self, request):
        expenses = Expense.objects.all()
        serializer = ExpenseSerializer(expenses, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = ExpenseSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

def download_expenses_api(request):
    """
    API endpoint to download expenses in CSV or JSON format, determined by the 'format' query parameter.
    """
    user = request.user
    expenses = Expense.objects.filter(user=user)
    format = request.GET.get('format', 'csv').lower()  # Default to CSV if not specified

    if format == 'csv':
        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="expenses.csv"'

        writer = csv.writer(response)
        writer.writerow(['Title', 'Amount', 'Category', 'Date'])  # CSV header
        for expense in expenses:
            writer.writerow([expense.title, expense.amount, expense.category, expense.date])

        return response

    elif format == 'json':
        expenses_data = [{
            'title': expense.title,
            'amount': str(expense.amount),  # Convert Decimal to string for JSON serialization
            'category': expense.category,
            'date': expense.date.isoformat()  # Convert date to ISO format
        } for expense in expenses]

        response = HttpResponse(json.dumps(expenses_data), content_type='application/json')
        response['Content-Disposition'] = 'attachment; filename="expenses.json"'

        return response
    else:
        return HttpResponse("Invalid format specified. Use 'csv' or 'json' as the 'format' query parameter.", status=400)
# class ExpenseListCreate(generics.ListCreateAPIView):
#     serializer_class = ExpenseSerializer
#     permission_classes = [permissions.IsAuthenticated]

#     def get_queryset(self):
#         return Expense.objects.filter(user=self.request.user)

#     def perform_create(self, serializer):
#         serializer.save(user=self.request.user)

# class ExpenseRetrieveUpdateDestroy(generics.RetrieveUpdateDestroyAPIView):
#     serializer_class = ExpenseSerializer
#     permission_classes = [permissions.IsAuthenticated]

#     def get_queryset(self):
#         return Expense.objects.filter(user=self.request.user)