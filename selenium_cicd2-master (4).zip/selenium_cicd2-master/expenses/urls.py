from django.urls import path
from django.contrib.auth.views import LogoutView, LoginView
from . import views
# from .views import ExpenseListCreateAPIView

app_name = "expenses"  # Namespacing for better organization

urlpatterns = [
    # 🌍 Public Pages
    path('', views.home, name='home'),
    path('register/', views.register, name='register'),
    
    # 🔐 Authentication
    path('login/', LoginView.as_view(template_name='expenses/login.html'), name='login'),
    path('logout/', LogoutView.as_view(), name='logout'),

    # 📊 Dashboard & Expenses
    path('dashboard/', views.dashboard, name='dashboard'),
    path('add/', views.add_expense, name='add_expense'),
    path('expenses/', views.expenses_list, name='expenses_list'),
    path('edit/<int:pk>/', views.edit_expense, name='edit_expense'),
    path('delete/<int:pk>/', views.delete_expense, name='delete_expense'),

    # 📜 Reports & Data Visualization
    path('reports/', views.reports_view, name='reports'),
    path('expense-category-data/', views.expense_category_data, name='expense_category_data'),

    # ⚙️ Settings
    path('settings/', views.settings_view, name='settings'),

    # 🔽 Downloading & Exporting Data
    path('expenses/download/<str:format>/', views.download_expenses, name='download_expenses'),

    path('api/expenses/download/<str:format>/', views.download_expenses_api, name='download_expenses_api'),
    # 💱 Currency Conversion
    path('convert_currency/', views.convert_currency_view, name="convert_currency"),

    # path('api/expenses/', ExpenseListCreateAPIView.as_view(), name='api_expenses'),
    path('api/expenses/download/', views.download_expenses_api, name='download_expenses_api'),
    # 🛠 API Endpoints (RESTful API for External Use)
    # path('api/expenses/', views.expenses_list, name='expenses_list'),
    # path('api/expenses/<int:id>/', views.expense_detail, name='api_expense_detail'),
]
