
# Automated UI Testing with Selenium in CI/CD for Cloud-Native Application

This project demonstrates how to implement and automate UI testing using **Selenium** within a **CI/CD pipeline using GitHub Actions**, and then deploy the tested application to an **AWS EC2 instance**.

---

##  Project Structure

```
.
├── .github/workflows/
│   └── ci_cd_pipeline.yml   # GitHub Actions workflow
├── tests/                   # Selenium UI test cases
│   └── test_expense_tracker.py
├── manage.py
├── requirements.txt
├── expense_tracker/         # Main Django app
└── README.md
```

---

## 🔧 Technologies & Tools

- **Python 3.10**
- **Django Web Framework**
- **Selenium WebDriver** – UI testing
- **PyTest** – Test runner
- **GitHub Actions** – CI/CD automation
- **AWS EC2** – Deployment platform
- **Gunicorn + NGINX** – Production server stack

---

##  Setup Instructions (Local)

1. **Clone the Repo**  
```bash
git clone https://github.com/your-username/selenium_cicd2.git
cd selenium_cicd2
```

2. **Create Virtual Environment**  
```bash
python3 -m venv venv
source venv/bin/activate
```

3. **Install Requirements**  
```bash
pip install -r requirements.txt
```

4. **Run the Django App Locally**  
```bash
python manage.py migrate
python manage.py runserver
```

5. **Run Selenium UI Tests**  
```bash
pytest tests/ --html=tests/report.html
```

---

##  GitHub Actions Workflow

The pipeline performs the following automatically when a push or pull request is made to `master`:

- Installs Python & dependencies
- Migrates DB & runs Django server
- Runs **Selenium tests** in headless browser
- Uploads test report (`tests/report.html`)
- If all tests pass, deploys to EC2 using **SSH GitHub Action**

📄 [View YAML File →](https://github.com/venkat2356/selenium_cicd2/blob/master/.github/workflows/ci.yml)

---

##  Sample Selenium Test Execution Output

```
============================= test session starts ==============================
collected 8 items
tests/test_expense_tracker.py ........ [100%]
- Generated html report: tests/report.html -
============================== 8 passed in 23.28s ==============================
```

Report uploaded: [selenium-test-report](https://github.com/venkat2356/selenium_cicd2/actions/runs/16595402289/artifacts/3638449426)

---

##  Deployment Details

Deployed to an **AWS EC2 Instance** using SSH.  
After successful test execution, the latest code is cloned and redeployed using:
- Gunicorn (WSGI Server)
- NGINX (Reverse Proxy)
- `systemd` service manager for reliability

> Deployment steps handled inside GitHub Actions with automatic pull, install, and restart.

---

## Screenshots

-  **GitHub Actions test run**

  ![](https://github.com/venkat2356/selenium_cicd2/blob/029c27e42f082ab4e170aab32d6428c74f6e49d6/Screenshot%202025-07-29%20220015.png)

-  **HTML test report**

  ![](https://github.com/venkat2356/selenium_cicd2/blob/029c27e42f082ab4e170aab32d6428c74f6e49d6/Screenshot%202025-07-29%20220211.png)
  
- **Deployed app screenshot**

  ![](https://github.com/venkat2356/selenium_cicd2/blob/b8ad27fc96f82f704e9139440088587c053d476c/Screenshot%202025-07-29%20215916.png)

-  **Failed test scenario**
  
- Changed element name in application(html page) "**+Add Expense**" -> **Add Expense**

 ![](https://github.com/venkat2356/selenium_cicd2/blob/029c27e42f082ab4e170aab32d6428c74f6e49d6/Screenshot%202025-07-28%20000450.png)

- In selenium test script it remains as: **+Add Expense**

 ![](https://github.com/venkat2356/selenium_cicd2/blob/029c27e42f082ab4e170aab32d6428c74f6e49d6/Screenshot%202025-07-28%20000423.png)

- Deployment **Failed**

 ![](https://github.com/venkat2356/selenium_cicd2/blob/029c27e42f082ab4e170aab32d6428c74f6e49d6/Screenshot%202025-07-28%20000344.png)

---

##  Author & Acknowledgements

Developed as part of MSc Research Project by:
- **Venkata Ratnam Atyam**
- Institution: National College of Ireland


## License

[MIT](https://github.com/venkat2356/selenium_cicd2?tab=MIT-1-ov-file#:~:text=Copyright%20(c)%20%5B2024,DEALINGS%20IN%20THE)

